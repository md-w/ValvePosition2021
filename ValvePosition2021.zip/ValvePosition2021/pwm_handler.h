/* 
 * File:   pwm_handler.h
 * Author: user
 *
 * Created on March 21, 2021, 10:51 PM
 */

#ifndef PWM_HANDLER_H
#define	PWM_HANDLER_H

#ifdef	__cplusplus
extern "C" {
#endif

void initPWM(void);
void setPWMDuty(unsigned int iVal);

#ifdef	__cplusplus
}
#endif

#endif	/* PWM_HANDLER_H */

